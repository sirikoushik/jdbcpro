package com.capgemini.bankWallet.service;



import com.capgemini.bankWallet.dao.BankWalletDao;
import com.capgemini.bankWallet.dao.BankWalletDaoImpl;
import com.capgemini.bankWallet.exception.InsufficientBalanceException;
import com.capgemini.bankWallet.model.Account;

public class BankWalletServiceImpl implements BankWalletService {

	BankWalletDao bdao=new BankWalletDaoImpl();
	@Override
	public boolean createAccount(String name, String mobileNo, String aadharNo,
			String pin) {
		Account a=new Account(name, mobileNo, aadharNo,10000, pin);
		a.setAccountNo();
				return bdao.saveAccount(a);
	}

	@Override
	public long showBalance(int accountNo, String pin) {
		return bdao.viewBalance(accountNo, pin);
	}

	@Override
	public long deposit(int accountNo, long amount) {
		
		return bdao.depositCash(accountNo, amount);
	}

	@Override
	public long withdraw(int accountNo, String pin,long amount) throws InsufficientBalanceException {
	 
		return bdao.withdrawCash(accountNo, pin, amount);
	}

	@Override
	public boolean fundTransfer(int sourceAcNo, int destAcNo, long amount,String pin) throws InsufficientBalanceException {
		return bdao.transferMoney(sourceAcNo, destAcNo, amount,pin);
	}
	@Override
	public boolean validateAccountNumber(int accNo)
	{
		String s=Integer.toString(accNo);
		if(s.matches("[1-9][0-9]{3}"))
			return true;
		System.err.println("Please Enter Valid 4 Digit Account Number");
		return false;
	}
	@Override
	public boolean validatePin(String pin)
	{
		if(pin.matches("[0-9]{4}"))
			return true;
		System.err.println("Please Enter Valid 4 Digit Pin");
		return false;
	}
	@Override
    public boolean validateName(String name)
    {
    	if(name.matches("[A-Z][a-z]*"))
    		return true;
    	System.err.println("Please Enter Valid Name");
		return false;
    }
	@Override
    public boolean validateMobileNumber(String moNo)
    {
    	if(moNo.matches("[6|7|8|9][0-9]{9}"))
    		return true;
    	System.err.println("Please Enter Valid Mobile Number");
		return false;
    }
	@Override
    public boolean validateAadharNumber(String aaNo)
    {
    	if(aaNo.matches("[0-9]{12}"))
    		return true;
    	System.err.println("Please Enter Valid Aadhar Number");
    	return false;
    }

	@Override
	public void ptr(int accno) {
		bdao.ptr(accno);
		
	}

}
