package com.capgemini.bankWallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.capgemini.bankWallet.dbutil.BankDbutil;
import com.capgemini.bankWallet.exception.InsufficientBalanceException;
import com.capgemini.bankWallet.model.Account;

import oracle.net.aso.a;

public class BankWalletDaoImpl implements BankWalletDao 
{
	
	private Connection con = null;
	PreparedStatement ps;
	public String dateAndTime()
	{
		DateFormat dAndT=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date d=new Date();
		return dAndT.format(d);
	}
	//accountsTable
	@Override
	public boolean saveAccount(Account a) 
	{
		BankDbutil bdb=new BankDbutil();
		con=bdb.getConnection();
		try {
			
			ps=con.prepareStatement("Insert into bankdb values(?,?,?,?,?,?)");
			ps.setInt(1, a.getAccountNo());
			ps.setString(2, a.getName());
			ps.setString(3, a.getMobileNo());
			ps.setString(4, a.getAadharNo());
			ps.setLong(5, a.getAccountBalance());
			ps.setString(6, a.getPin());
			int i=ps.executeUpdate();
			if(i>0) {
				ps=con.prepareStatement("Insert into transactions values(?,?)");
				ps.setInt(1, a.getAccountNo());
				ps.setString(2, "Account created on "+ dateAndTime());
				ps.executeUpdate();
				return true;
			}
				
	
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;	
	}

	@Override
	public long viewBalance(int accountNo, String pin) 
	{
	   long balance;
	   BankDbutil bdb=new BankDbutil();
	   con=bdb.getConnection();
       try {
		ps=con.prepareStatement("Select * from bankdb where AccNum=? and pin=?");
		ps.setInt(1, accountNo);
		ps.setString(2,pin);
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			balance=rs.getLong(5);
			return balance;
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
		return -1;
	}

	@Override
	public long depositCash(int accountNo,long amount) 
	{
		long accBal;
		BankDbutil bdb=new BankDbutil();
		con=bdb.getConnection();
		try {
			ps=con.prepareStatement("select accbal from bankdb where accnum=?");
            ps.setInt(1, accountNo);
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {            	
            	accBal=rs.getLong(1);
            	ps=con.prepareStatement("update bankdb set accbal=? where accnum=?");
            	ps.setLong(1, accBal+amount);
            	ps.setInt(2, accountNo);
            	int i=ps.executeUpdate();
            	if(i>0)
            	{
            		ps=con.prepareStatement("Insert into transactions values(?,?)");
    				ps.setInt(1, accountNo);
    				ps.setString(2, "Amount "+amount+"deposited on "+ dateAndTime());
    				ps.executeUpdate();
            		return accBal+amount;
            	}
            }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return -1;
	}

	@Override
	public long withdrawCash(int accountNo, String pin,long amount) throws InsufficientBalanceException 
	{
		long accBal;
		BankDbutil bdb=new BankDbutil();
		con=bdb.getConnection();
		try {
			ps=con.prepareStatement("select accbal from bankdb where accnum=? and pin=?");
            ps.setInt(1, accountNo);
            ps.setString(2, pin);
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {  
            	accBal=rs.getLong(1);
            	if(accBal>=amount)
            	{
            	ps=con.prepareStatement("update bankdb set accbal=? where accnum=?");
            	ps.setLong(1, accBal-amount);
            	ps.setInt(2, accountNo);
            	int i=ps.executeUpdate();
            	if(i>0)
            	{
            		ps=con.prepareStatement("Insert into transactions values(?,?)");
    				ps.setInt(1,accountNo);
    				ps.setString(2, "Amount "+amount+ "withdrawn on "+ dateAndTime());
    				ps.executeUpdate();
            		return accBal-amount;
            	}
            	}
            	else throw new InsufficientBalanceException("Insufficient Balance");
            }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}

	@Override
	public boolean transferMoney(int sourceAcNo, int destAcNo, long amount,String pin) throws InsufficientBalanceException {
		long accBal;
		BankDbutil bdb=new BankDbutil();
		con=bdb.getConnection();
		ResultSet rs;
		int i;
		try {
			ps=con.prepareStatement("select accbal from bankdb where accnum=? and pin=?");
            ps.setInt(1, sourceAcNo);
            ps.setString(2, pin);
            rs=ps.executeQuery();
            while(rs.next())
            {   
            	accBal=rs.getLong(1);
            	if(accBal>=amount)
            	{
            	 ps=con.prepareStatement("update bankdb set accbal=? where accnum=?");
            	 ps.setLong(1, accBal-amount);
            	 ps.setInt(2, sourceAcNo);
            	 i=ps.executeUpdate();
            	 
            	 ps=con.prepareStatement("select accbal from bankdb where accnum=?");
            	 ps.setInt(1, destAcNo);
            	 rs=ps.executeQuery();
            	 while(rs.next())
            	 {
            		 accBal=rs.getLong(1);
            		 ps=con.prepareStatement("update bankdb set accbal=? where accnum=?");
            		 ps.setLong(1, accBal+amount);
                	 ps.setInt(2, destAcNo);
                	 ps.executeUpdate();
            	 }
            	 if(i>0)
            	 {
            		ps=con.prepareStatement("Insert into transactions values(?,?)");
     				ps.setInt(1,sourceAcNo);
     				ps.setString(2, "Amount "+amount + "transferred on " +dateAndTime());
     				ps.executeUpdate();
            		return true;
            	 }
            	
            	}
            	else throw new InsufficientBalanceException("Insufficient Balance");
            }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public void ptr(int accno) {
		try {
			ps=con.prepareStatement("select transaction from transactions where accno=?");
			ps.setInt(1, accno);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				System.out.println(rs.getString(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
