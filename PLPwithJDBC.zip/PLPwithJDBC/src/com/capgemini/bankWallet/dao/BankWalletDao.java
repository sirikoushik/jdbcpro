package com.capgemini.bankWallet.dao;

import com.capgemini.bankWallet.exception.InsufficientBalanceException;
import com.capgemini.bankWallet.model.Account;

public interface BankWalletDao 
{
	  boolean saveAccount(Account a);
	  long viewBalance(int accountNo,String pin);
	  long depositCash(int accountNo,long amount);
	  long withdrawCash(int accountNo,String pin,long amount) throws InsufficientBalanceException;
	  boolean transferMoney(int sourceAcNo,int destAcNo,long amount,String pin) throws InsufficientBalanceException;
	  void ptr(int accno);
}
